let web3;
let contract;
const contractAddress = '0x7F6083Afe3CbA9F59F53671839eE05bf794cA09F'; // Replace with your contract address


document.addEventListener("DOMContentLoaded", async function () {
    if (typeof window.ethereum !== 'undefined') {
        web3 = new Web3("http://ec2-52-71-252-134.compute-1.amazonaws.com:7545");
        document.getElementById('connectButton').addEventListener('click', connectWallet);
        document.getElementById('assignRoleButton').addEventListener('click', assignRole);
        document.getElementById('revokeRoleButton').addEventListener('click', revokeRole);
        document.getElementById('checkRoleButton').addEventListener('click', checkRole);
        document.getElementById('transferRoleButton').addEventListener('click', transferRole);
        document.getElementById('adminFunctionButton').addEventListener('click', adminFunction);
        document.getElementById('managerFunctionButton').addEventListener('click', managerFunction);
        document.getElementById('employeeFunctionButton').addEventListener('click', employeeFunction);
        document.getElementById('publicFunctionButton').addEventListener('click', publicFunction);

        // Listen for account changes
        window.ethereum.on('accountsChanged', handleAccountsChanged);

        // Initial check of accounts
        await handleAccountsChanged();
    } else {
        alert('MetaMask is not installed. Please install MetaMask to use this dApp.');
    }
});

async function connectWallet() {
    try {
        console.log('Requesting account access');
        await window.ethereum.request({ method: 'eth_requestAccounts' });

        console.log('Account access requested');
        await handleAccountsChanged();
    } catch (error) {
        console.error('Error requesting account access:', error);
    }
}

async function handleAccountsChanged() {
    try {
        const accounts = await window.ethereum.request({ method: 'eth_accounts' });
        if (accounts.length === 0) {
            console.log('No accounts found');
            document.getElementById('walletAddress').textContent = 'Not connected';
            return;
        }

        const account = accounts[0];
        console.log('Connected account:', account);
        document.getElementById('walletAddress').textContent = `Connected: ${account}`;
        const response = await fetch("./client/contracts/IAM.json");
        const data = await response.json();
        contract = new web3.eth.Contract(data.abi, contractAddress);
    } catch (error) {
        console.error('Error fetching accounts or contract:', error);
    }
}

async function assignRole() {
    const address = document.getElementById('assignAddress').value;
    const role = document.getElementById('assignRole').value;
    const accounts = await window.ethereum.request({ method: 'eth_accounts' });
    const from = accounts[0];

    try {
        console.log('Assigning role', role, 'to address', address, 'from', from);
        await contract.methods.assignRole(address, role).send({
            from: from,
            gasPrice: web3.utils.toWei('100', 'gwei') // Use gasPrice for legacy transactions
        });
        alert('Role assigned successfully');
    } catch (error) {
        console.error('Error assigning role:', error);
        alert('Failed to assign role');
    }
}

async function revokeRole() {
    const address = document.getElementById('revokeAddress').value;
    const accounts = await window.ethereum.request({ method: 'eth_accounts' });
    const from = accounts[0];

    try {
        console.log('Revoking role from address', address, 'from', from);
        await contract.methods.revokeRole(address).send({
            from: from,
            gasPrice: web3.utils.toWei('100', 'gwei') // Use gasPrice for legacy transactions
        });
        alert('Role revoked successfully');
    } catch (error) {
        console.error('Error revoking role:', error);
        alert('Failed to revoke role');
    }
}

async function checkRole() {
    const accounts = await window.ethereum.request({ method: 'eth_accounts' });
    const from = accounts[0];

    if (!contract) {
        alert('Contract not initialized');
        return;
    }

    try {
        const role = await contract.methods.checkRole().call({ from });
        const roleString = ['NONE', 'EMPLOYEE', 'MANAGER', 'ADMIN'][role];
        document.getElementById('roleResult').textContent = `Role: ${roleString}`;
    } catch (error) {
        console.error(error);
        alert('Failed to check role');
    }
}

async function transferRole() {
    const address = document.getElementById('transferAddress').value;
    const accounts = await window.ethereum.request({ method: 'eth_accounts' });
    const from = accounts[0];

    try {
        console.log('Transferring role to address', address, 'from', from);
        await contract.methods.transferRole(address).send({
            from: from,
            gasPrice: web3.utils.toWei('100', 'gwei') // Use gasPrice for legacy transactions
        });
        alert('Role transferred successfully');
    } catch (error) {
        console.error('Error transferring role:', error);
        alert('Failed to transfer role');
    }
}

async function adminFunction() {
    const accounts = await window.ethereum.request({ method: 'eth_accounts' });
    const from = accounts[0];

    try {
        console.log('Executing admin function from', from);
        await contract.methods.adminFunction().send({
            from: from,
            gasPrice: web3.utils.toWei('100', 'gwei') // Use gasPrice for legacy transactions
        });
        document.getElementById('adminFunctionResult').textContent = 'Admin function executed successfully.';
    } catch (error) {
        console.error('Error executing admin function:', error);
        document.getElementById('adminFunctionResult').textContent = 'Failed to execute admin function.';
    }
}

async function managerFunction() {
    const accounts = await window.ethereum.request({ method: 'eth_accounts' });
    const from = accounts[0];

    try {
        console.log('Executing manager function from', from);
        await contract.methods.managerFunction().send({
            from: from,
            gasPrice: web3.utils.toWei('100', 'gwei') // Use gasPrice for legacy transactions
        });
        document.getElementById('managerFunctionResult').textContent = 'Manager function executed successfully.';
    } catch (error) {
        console.error('Error executing manager function:', error);
        document.getElementById('managerFunctionResult').textContent = 'Failed to execute manager function.';
    }
}

async function employeeFunction() {
    const accounts = await window.ethereum.request({ method: 'eth_accounts' });
    const from = accounts[0];

    try {
        console.log('Executing employee function from', from);
        await contract.methods.employeeFunction().send({
            from: from,
            gasPrice: web3.utils.toWei('100', 'gwei') // Use gasPrice for legacy transactions
        });
        document.getElementById('employeeFunctionResult').textContent = 'Employee function executed successfully.';
    } catch (error) {
        console.error('Error executing employee function:', error);
        document.getElementById('employeeFunctionResult').textContent = 'Failed to execute employee function.';
    }
}

async function publicFunction() {
    const accounts = await window.ethereum.request({ method: 'eth_accounts' });
    const from = accounts[0];

    try {
        console.log('Executing public function from', from);
        await contract.methods.publicFunction().send({
            from: from,
            gasPrice: web3.utils.toWei('100', 'gwei') // Use gasPrice for legacy transactions
        });
        document.getElementById('publicFunctionResult').textContent = 'Public function executed successfully.';
    } catch (error) {
        console.error('Error executing public function:', error);
        document.getElementById('publicFunctionResult').textContent = 'Failed to execute public function.';
    }
}