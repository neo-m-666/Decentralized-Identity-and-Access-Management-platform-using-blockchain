const IAM = artifacts.require("IAM");
module.exports = function (deployer) {
    deployer.deploy(IAM);
};